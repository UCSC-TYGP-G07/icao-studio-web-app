import { Text } from "@mantine/core";
import Navbar from "../components/Navbar";

function Index(){
    return (
        <>
            <Navbar />
            <Text>Index Page</Text>
        </>

    );
}

export default Index;