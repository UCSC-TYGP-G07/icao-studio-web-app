interface ICAOProgressDTO{
    all_passed: boolean;
    tests: {
        geometry: TestDTO,
        blurring: TestDTO,
        varied_bg: TestDTO
    }
}

interface TestDTO{
    is_passed: boolean;
    time_elapsed: number;
}

export default ICAOProgressDTO;