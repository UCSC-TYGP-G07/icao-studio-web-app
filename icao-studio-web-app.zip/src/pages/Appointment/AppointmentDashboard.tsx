import Navbar from "../../components/Navbar";
import Bottombar from "../../components/Bottombar";
import {Container, Flex, Header, Image, Modal, Title} from "@mantine/core";
import React, {useState} from "react";
import {useDisclosure, useViewportSize} from "@mantine/hooks";
import IconCancel from "../../assets/message-icons/icons8-cancel.svg";
import IconCheck from "../../assets/message-icons/icons8-checkmark-150.svg";

export default function AppointmentDashboard() {
    /* Getting current viewport sizes */
    const {width, height} = useViewportSize();

    /* Managing modal elements */
    const [modalColor, setModalColor] = useState('green.9');
    const [modalText, setModalText] = useState('');
    const [modalIcon, setModalIcon] = useState(IconCancel);

    const [overlayVisible, setOverlayVisible] = useState(false);
    const [overlayClosable, setOverlayClosable] = useState(false);

    /* Managining the modal */
    const [opened, { open, close }] = useDisclosure(false);

    /* Closing the overlay */
    function closeModal(){
        close();
    }

    return <>
        { overlayVisible &&
            <Modal opened={opened} onClose={close} withCloseButton={false} closeOnClickOutside={overlayClosable} centered>
                <Flex direction='row' align='center' justify='center'>
                    <Image src={modalIcon} maw={32} mx={12}/>
                    <Title weight='normal' ml={4} order={4} align='center' color={modalColor}>{modalText}</Title>
                </Flex>
            </Modal>
        }
        <Navbar protectedRoute={true}/>
        <Flex direction='row' align='center' justify='space-evenly' w={width - 48} h={height - 96} py='auto' mx={24}>
            <Container fluid style={{ backgroundColor: '#758BFD'}}>
                {/*<Header>OneID Studio Dashboard</Header>*/}
            </Container>
        </Flex>
        <Bottombar />
    </>
}