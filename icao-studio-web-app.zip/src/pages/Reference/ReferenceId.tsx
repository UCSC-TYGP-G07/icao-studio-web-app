import {
    Badge,
    Box,
    Button,
    Center,
    Container,
    Flex,
    Image,
    Progress,
    ScrollArea,
    Stepper,
    Table,
    Text,
    Title
} from "@mantine/core";
import Navbar from "../../components/Navbar";
import {useParams} from "react-router-dom";
import Bottombar from "../../components/Bottombar";
import {useMediaQuery, useViewportSize} from "@mantine/hooks";
import ImageUpload from "../../components/Image/ImageUpload";
import axios from "axios";
import React, {useState} from "react";
import {modals} from "@mantine/modals";
import IconCancel from "../../assets/message-icons/icons8-cancel.svg";
import UploadImage from "../../assets/images/upload-image.svg";
import ICAOGuidelines, {ICAOGuideLine} from "../../data/ICAOGuildelines";
import ICAOProgressDTO from "../../services/ICAOProgressDTO";
import ICAOProgressCard from "../../components/ICAOProgressCard";
import ICAOProgressTable from "../../components/ICAOProgressTable";

function ReferenceId(){
    /* Getting the reference id from params */
    const { refId } = useParams();
    const { width, height } = useViewportSize();

    /* Use of media query */
    const largeScreen = useMediaQuery('(min-width: 60em)');

    /* TODO: Update the state to empty */
    const [ uploadState, setUploadState ] = useState<PhotoUploadState>(PhotoUploadState.EMPTY_IMAGE);

    const [ overallValidity, setOverallValidity ] = useState<boolean | null>(null);
    const [ icaoComValue, setIcaoComValue ] = useState<ICAOGuideLine[] | null>(ICAOGuidelines);

    const checkImageValidity = async (file: File) => {
        /* Handling ICAO image checking */

        const formData = new FormData();
        formData.append('file', file);
        const postUrl = `${process.env.REACT_APP_ICAO_VALIDATE_BACKEND}/validate_icao`;

        setUploadState(PhotoUploadState.CHECKING_IMAGE);

        setOverallValidity(true);
        setUploadState(PhotoUploadState.CHECKED_VALID_IMAGE);

        await axios.post(postUrl,
            formData, { headers: {
                        'Content-Type': 'multipart/form-data',
            }}).then(response => {
                const data = response.data;
                const icao_compliant: boolean = data.is_icao_compliant;

                setOverallValidity(icao_compliant);

                if(icao_compliant){
                    setUploadState(PhotoUploadState.CHECKED_VALID_IMAGE);
                } else {
                    setUploadState(PhotoUploadState.CHECKED_INVALID_IMAGE);
                }
            })
            .catch(err => {
                // TODO: Remove commented parts
                showErrorMessage('Internal server error. Please try again later!');
            });
    }

    /* Handling error messages */
    const showErrorMessage = (errorText: string) => {
        modals.open({
            children: (
                <Flex direction='row' align='center' justify='center'>
                    <Image src={IconCancel} maw={32} mx={12}/>
                    <Title weight='normal' ml={4} order={4} align='center' color='red.9'>{errorText}</Title>
                </Flex>
            ),
            withCloseButton: false,
            closeOnClickOutside: false,
            centered: true
        });
    }

    const icaoProgress: ICAOProgressDTO = {
        all_passed: false,
        tests: {
            geometry: {
                is_passed: false,
                time_elapsed: 0.0
            },
            blurring: {
                is_passed: true,
                time_elapsed: 0.004
            },
            varied_bg: {
                is_passed: true,
                time_elapsed: 0.688
            }
        }
    }

    return (
        <>
            <Navbar protectedRoute={true} />
            <Flex direction={ largeScreen ? 'row' : 'column'}>
                <Box w={largeScreen ? width * 0.7 : width} h={height - 96}>
                    <Box h={120} p={12} w='full' bg='red.1'>
                        <Title order={3}>Applicant details</Title>
                    </Box>
                    <Box p={12} pl={28}>
                        <Title order={3}>ICAO compliance score</Title>
                        { (uploadState === PhotoUploadState.EMPTY_IMAGE || uploadState === PhotoUploadState.SELECTED_IMAGE || uploadState === PhotoUploadState.CHECKING_IMAGE) &&
                            <Flex direction='column' align='center'>
                                <Image maw={240} mt={12} mx='auto' src={UploadImage} />
                                <Text>Please upload the image to check compliance score</Text>
                            </Flex>
                        }

                        { (uploadState === PhotoUploadState.CHECKED_VALID_IMAGE || uploadState === PhotoUploadState.CHECKED_INVALID_IMAGE) &&
                            <>
                                <Text size='sm'>ICAO validity status - { overallValidity ? <Badge color='success'>Valid Image</Badge> : <Badge color='error'>Invalid Image</Badge>}</Text>
                                { /* ICAO guideline summary */}
                                <Container fluid  p={12} pt={24}>
                                    <ICAOProgressCard icaoProgress={icaoProgress} />
                                    <ICAOProgressTable icaoProgress={icaoProgress} />
                                </Container>
                            </>
                        }
                    </Box>
                </Box>
                <Flex direction='column' w={largeScreen ? width * 0.3 : width} h={height - 96} bg='gray.0' align='center' justify='center'>
                    <ImageUpload uploadState={uploadState} setUploadState={setUploadState} width={largeScreen ? width * 0.35 * 0.8 : width * 0.8} height={(height - 96) * 0.8} showErrorMessage={showErrorMessage} checkImageValidity={checkImageValidity}/>
                </Flex>
            </Flex>
            <Bottombar />
        </>

    );
}

/* Enums for handling image upload state */
export enum PhotoUploadState{
    EMPTY_IMAGE = "EMPTY_IMAGE",
    SELECTED_IMAGE = "SELECTED_IMAGE",
    CHECKING_IMAGE = "CHECKING_IMAGE",
    CHECKED_VALID_IMAGE = "CHECKED_VALID_IMAGE",
    CHECKED_INVALID_IMAGE = "CHECKED_INVALID_IMAGE"
}

export default ReferenceId;